# Trading Skill Tree Course Website

## How to Run

1. Install dependencies:
   ```
   npm install
   ```

2. Run locally:
   ```
   npm start
   ```

3. To deploy:
   - Push to GitHub
   - Connect to Vercel (https://vercel.com)
