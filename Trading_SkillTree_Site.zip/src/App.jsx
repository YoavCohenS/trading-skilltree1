import { useState } from "react";
import { BrowserRouter as Router, Route, Routes, useNavigate } from "react-router-dom";

const skillTreeData = [
  { id: "intro", title: "Introduction to Day Trading", description: "Start here to learn the basics of the market.", unlocked: true },
  { id: "candles", title: "Japanese Candlesticks", description: "Learn how to read price action through candle patterns.", unlocked: false },
  { id: "origin", title: "Origin Levels", description: "Understand how moves begin and where they fail.", unlocked: false },
];

function SkillTree() {
  const [skills, setSkills] = useState(skillTreeData);
  const unlockNext = (index) => {
    const updated = [...skills];
    if (updated[index + 1]) updated[index + 1].unlocked = true;
    setSkills(updated);
  };
  return (
    <div style={{ maxWidth: "600px", margin: "auto", padding: "1rem" }}>
      {skills.map((node, index) => (
        <div key={node.id} style={{
          opacity: node.unlocked ? 1 : 0.4,
          pointerEvents: node.unlocked ? "auto" : "none",
          border: "1px solid #ccc", borderRadius: "8px", marginBottom: "1rem", padding: "1rem"
        }}>
          <h2>{node.title}</h2>
          <p>{node.description}</p>
          {node.unlocked && index < skills.length - 1 && (
            <button onClick={() => unlockNext(index)}>Unlock Next</button>
          )}
        </div>
      ))}
    </div>
  );
}

function Home() {
  const navigate = useNavigate();
  const handleBuy = () => {
    alert("Redirecting to payment...");
    navigate("/course");
  };
  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h1>Trading Mastery</h1>
      <p>Learn the science of price action through an interactive skill tree.</p>
      <button onClick={handleBuy}>Buy Now</button>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/course" element={<SkillTree />} />
      </Routes>
    </Router>
  );
}
